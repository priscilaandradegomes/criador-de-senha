const numeroSenha = document.querySelector('parametro-senha_texto');

